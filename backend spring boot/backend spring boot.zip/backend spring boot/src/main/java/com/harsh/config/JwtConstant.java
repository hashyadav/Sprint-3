package com.harsh.config;

public class JwtConstant {
	public static final String SECRET_KEY="wpembytrwcvnryxksdbqwjebruyGHyudqgwveytrtrCSnwifoesarjbwe";
	public static final String JWT_HEADER="Authorization";
}
